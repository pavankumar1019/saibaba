Ajax image upload
=================

A simple tutorial to explain how to implement ajax image uploading using jquery and php with a beautiful progress bar from bootstrap


Video Tutorial : http://youtu.be/flaiEXVkdgE

Live Demo : http://packetcode.com/apps/ajax-image-upload/
