</div><!--Container -->
<script src="js/bootstrap.js"></script>
</body>
<script type="text/javascript">
	function del(){
		var del = confirm("Do you really want to delete this");
		if(del){
			return true;
		}
		else{
			return false;
		}
	}

</script>
</html>
